import tkinter as tk
from tkinter import messagebox
import random

# --- Настройки стиля ---
BG_COLOR = "#1c1c1e"
BTN_COLOR = "#2c2c2e"
BTN_HOVER = "#3a3a3c"
FG_COLOR = "#ffffff"
FONT = ("Helvetica", 18, "bold")
TITLE_FONT = ("Helvetica", 26, "bold")
ENTRY_FONT = ("Helvetica", 22)

# --- Анимация заголовка ---
def animate_title():
    global title_index
    title_index = (title_index + 1) % (len(title_text)+1)
    title_label.config(text=title_text[:title_index])
    root.after(100, animate_title)

def on_enter(e):
    e.widget.config(bg=BTN_HOVER)

def on_leave(e):
    e.widget.config(bg=BTN_COLOR)

# --- Калькулятор ---
secret_seq = []

def press(key):
    global secret_seq
    entry_var.set(entry_var.get() + str(key))
    secret_seq.append(key)
    if secret_seq[-4:] == ['7','7','6','6']:
        secret_seq.clear()
        open_secret_confirmation()
    elif len(secret_seq) > 4:
        secret_seq.pop(0)

def clear():
    entry_var.set("")

def calculate():
    try:
        result = eval(entry_var.get())
        entry_var.set(result)
    except:
        messagebox.showerror("Ошибка", "Неверное выражение!")

# --- Окно подтверждения запуска секретной игры ---
def open_secret_confirmation():
    win = tk.Toplevel()
    win.attributes("-fullscreen", True)
    win.configure(bg=BG_COLOR)

    msg = tk.Label(win, text="Привет!\nВы нашли секретную игру 'Змейка'.\nХотите открыть её?",
                   fg=FG_COLOR, bg=BG_COLOR, font=("Helvetica", 28))
    msg.pack(expand=True)

    def yes():
        win.destroy()
        open_snake_warning()

    def no():
        win.destroy()

    btn_frame = tk.Frame(win, bg=BG_COLOR)
    btn_frame.pack(pady=30)

    for txt, cmd in [("Да", yes), ("Нет", no)]:
        b = tk.Button(btn_frame, text=txt, font=("Helvetica", 28),
                      fg=FG_COLOR, bg=BTN_COLOR, activebackground=BTN_HOVER,
                      bd=0, padx=40, pady=20, relief="flat", command=cmd)
        b.pack(side="left", padx=50)
        b.bind("<Enter>", on_enter)
        b.bind("<Leave>", on_leave)

# --- Предупреждение и 3-секундная задержка перед запуском змейки ---
def open_snake_warning():
    win = tk.Toplevel()
    win.attributes("-fullscreen", True)
    win.configure(bg=BG_COLOR)
    msg = tk.Label(win, text="Управление: стрелки ← ↑ ↓ →\nИгра начнётся через 3 секунды...",
                   fg=FG_COLOR, bg=BG_COLOR, font=("Helvetica", 28))
    msg.pack(expand=True)
    win.after(3000, lambda: (win.destroy(), start_snake()))

# --- Игра Змейка ---
def start_snake():
    for w in root.winfo_children():
        w.destroy()
    root.configure(bg=BG_COLOR)

    canvas = tk.Canvas(root, bg=BG_COLOR, width=400, height=400, highlightthickness=0)
    canvas.pack(pady=10)

    snake = [(100,100),(90,100),(80,100)]
    direction = "Right"
    food = None
    game_running = True

    def spawn_food():
        return (random.randint(0,39)*10, random.randint(0,39)*10)

    def draw():
        canvas.delete("all")
        for x, y in snake:
            canvas.create_rectangle(x, y, x+10, y+10, fill=FG_COLOR, outline=FG_COLOR)
        if food:
            canvas.create_oval(food[0], food[1], food[0]+10, food[1]+10, fill="red", outline="red")

    def move():
        nonlocal food, direction, game_running
        if not game_running:
            return
        x, y = snake[0]
        if direction == "Right": x+=10
        elif direction == "Left": x-=10
        elif direction == "Up": y-=10
        elif direction == "Down": y+=10
        new = (x, y)
        if x < 0 or x >= 400 or y < 0 or y >= 400 or new in snake:
            game_over()
            return
        snake.insert(0, new)
        if food and new == food:
            food = spawn_food()
        else:
            snake.pop()
        draw()
        root.after(120, move)

    def game_over():
        nonlocal game_running
        game_running = False
        canvas.create_text(200,200, text="GAME OVER", fill="red",
                           font=("Helvetica", 28, "bold"))
        show_restart_button()

    def key_press(e):
        nonlocal direction
        if e.keysym in ("Up","Down","Left","Right"):
            if (direction == "Left" and e.keysym != "Right") or \
               (direction == "Right" and e.keysym != "Left") or \
               (direction == "Up" and e.keysym != "Down") or \
               (direction == "Down" and e.keysym != "Up"):
                direction = e.keysym

    def show_restart_button():
        btn = tk.Button(root, text="Restart Snake", font=("Helvetica", 20),
                        fg=FG_COLOR, bg=BTN_COLOR, activebackground=BTN_HOVER,
                        bd=0, padx=20, pady=10, command=lambda: (btn.destroy(), start_snake()))
        btn.pack(pady=20)
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

    root.bind("<KeyPress>", key_press)
    food = spawn_food()
    move()

# --- Главное окно калькулятора ---
root = tk.Tk()
root.title("Immortal Calculator")
root.geometry("420x520")
root.resizable(False, False)
root.configure(bg=BG_COLOR)

title_text = "Immortal Calculator"
title_index = 0
title_label = tk.Label(root, text="", fg=FG_COLOR, bg=BG_COLOR, font=TITLE_FONT)
title_label.pack(pady=15)
animate_title()

entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=ENTRY_FONT,
                 bg=BG_COLOR, fg=FG_COLOR, insertbackground=FG_COLOR,
                 bd=0, relief="flat", justify="right")
entry.pack(fill="x", padx=20, pady=10, ipady=10)

btns = [
    ['7','8','9','/'],
    ['4','5','6','*'],
    ['1','2','3','-'],
    ['0','.','=','+']
]

for row in btns:
    fr = tk.Frame(root, bg=BG_COLOR)
    fr.pack(expand=True, fill="both", padx=10, pady=5)
    for t in row:
        b = tk.Button(fr, text=t, font=FONT, fg=FG_COLOR,
                      bg=BTN_COLOR, activebackground=BTN_HOVER, bd=0,
                      relief="flat", command=(calculate if t == "=" else lambda x=t: press(x)))
        b.pack(side="left", expand=True, fill="both", padx=5, pady=5)
        b.bind("<Enter>", on_enter)
        b.bind("<Leave>", on_leave)

clear_btn = tk.Button(root, text="C", font=FONT, fg=FG_COLOR,
                      bg="#ff3b30", activebackground="#ff5e57",
                      bd=0, relief="flat", command=clear)
clear_btn.pack(fill="x", padx=20, pady=10, ipady=10)

root.mainloop()
